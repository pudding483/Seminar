using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using WebSocketSharp;

public class WebSocketClient : MonoBehaviour
{
    public WebSocket ws;
    bool ws_appear()
    {
        return ws != null && ws.ReadyState == WebSocketState.Open;
    }

    void Start()
    {
        string serverUrl = "ws://localhost:5000"; // 服务器的 WebSocket 地址
        ws = new WebSocket(serverUrl);

        ws.OnOpen += OnOpen;
        ws.OnMessage += OnMessage;
        ws.OnClose += OnClose;

        ws.Connect();
    }

    void OnOpen(object sender, System.EventArgs e)
    {
        Debug.Log("Connected to server");
        // 在连接成功后，您可以在这里执行一些初始化操作或向服务器发送一些数据
        sendvarify();
    }

    void OnMessage(object sender, MessageEventArgs e)
    {
        string message = e.Data;
        Debug.Log("Received message from server: " + message);
        
    }

    void OnClose(object sender, CloseEventArgs e)
    {
        Debug.Log("Connection closed");
        // 在连接关闭时执行一些清理操作
    }

    void OnDestroy()
    {
        if (ws_appear())
        {
            ws.Close();
        }
    }

    public void sendvarify()
    {
        if (ws_appear())
        {
            // 创建包含 "isUnity": true 的匿名对象
            string jsonStr = "{ \"isUnity\": true }";
            Debug.Log(jsonStr);
            ws.Send(jsonStr);

        }
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) && ws_appear())
        {
            string jsonStr = "123456789";
            Debug.Log(jsonStr);
            ws.Send(jsonStr);
        }
    }
}
