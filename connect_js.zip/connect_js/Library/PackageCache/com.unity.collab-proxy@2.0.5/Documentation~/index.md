# About Version Control

The Version Control package provides an in-editor interface for teams to work with Unity version control (Unity VC).
## Unity VC

Unity VC plug-in for Unity is a free Unity plug-in that gives you the ability to use Unity VC, a leading version control solution, directly in Unity. Get started with [Unity VC](QuickStartGuide.md).

