using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawn_manage : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject s;
    public void studentspawn(string id)
    {
        if (s != null)
        {
            GameObject std = Instantiate(s, transform.position, transform.rotation);
            player_view targetScript = std.GetComponent<player_view>();
            if (targetScript != null)
            {
                Debug.Log("id in");
                targetScript.set_id(id);
            }

            Debug.Log("test end");
        }
    }
}
