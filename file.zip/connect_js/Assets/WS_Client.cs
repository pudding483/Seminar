using WebSocketSharp;
using UnityEngine;

public class WS_Client : MonoBehaviour
{
    WebSocket io;
    [SerializeField] int url_port = 5000;
    void Start()
    {
        io = new WebSocket($"ws://localhost:{url_port}");
        io.OnMessage += (sender, msg) =>
        {
            Debug.Log("收到");
            Debug.Log("msg:" + msg.Data);
        };
        io.Connect();
    }

    // Update is called once per frame
    void Update()
    {
        if (io == null)
        {
            return;
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            io.Send("太美");
        }
    }
}
